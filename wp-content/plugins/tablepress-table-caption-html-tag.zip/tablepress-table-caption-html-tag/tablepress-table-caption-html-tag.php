<?php
/*
Plugin Name: TablePress Extension: Table Caption HTML tag
Plugin URI: https://tablepress.org/extensions/table-caption-html-tag/
Description: Custom Extension for TablePress to use the HTML <caption> tag
Version: 1.0
Author: Tobias Bäthge
Author URI: https://tobias.baethge.com/
*/

add_filter( 'tablepress_print_caption_text', 'tablepress_table_caption_html_tag', 10, 2 );

/**
 * Print the table name in the <caption> element of the table.
 *
 * @since 1.0
 *
 * @param string $caption Caption of the table.
 * @param array  $table   Table.
 * @return string Extend caption of the table.
 */
function tablepress_table_caption_html_tag( $caption, $table ) {
	$caption = preg_replace( '/&(?![A-Za-z]{0,4}\w{2,3};|#[0-9]{2,4};)/', '&amp;', $table['name'] );
	return $caption;
}
